#!/system/bin/sh
if ! applypatch -c EMMC:/dev/block/mmcblk0p10:2048:002d1c1b94e16bbe81a4eb51c0670a9a67d9a020; then
  log -t recovery "Installing new recovery image"
  applypatch EMMC:/dev/block/mmcblk0p11:3643392:54b2f75e90e2ee4c747ecd3e733a8ce06dc57ba5 EMMC:/dev/block/mmcblk0p10 0de13cc8bc115dd7bd1ef08c97eb3379072a085d 4235264 54b2f75e90e2ee4c747ecd3e733a8ce06dc57ba5:/system/recovery-from-boot.p
else
  log -t recovery "Recovery image already installed"
fi
