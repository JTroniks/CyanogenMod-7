#!/system/bin/sh
if ! applypatch -c EMMC:/dev/block/mmcblk0p10:2048:f8fa16cd3549e7f7f3738e9132c510397899bdbc; then
  log -t recovery "Installing new recovery image"
  applypatch EMMC:/dev/block/mmcblk0p11:3620864:4e8404dc531b01c753ecbcdb68d4a26faae2cf49 EMMC:/dev/block/mmcblk0p10 12686e83c020aca03da42a45a257a072eb6f8d6e 4212736 4e8404dc531b01c753ecbcdb68d4a26faae2cf49:/system/recovery-from-boot.p
else
  log -t recovery "Recovery image already installed"
fi
